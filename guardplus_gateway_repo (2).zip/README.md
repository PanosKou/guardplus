
# GuardPlus Gateway

GuardPlus is a high-performance, extensible Rust-based service gateway designed as a modern, secure, and observable replacement for Traefik, NGINX, or Apache.

## 🔥 Key Features

- 🔐 **OIDC/JWT Auth** — Multi-provider (Google, GitHub, Auth0) with JWKS auto-discovery
- 📊 **Prometheus Metrics** — Rich HTTP/gRPC/TCP observability
- ⚡ **gRPC + TCP/UDP Support** — Proxy multiple protocols with metrics
- 🔁 **Consul Integration** — Dynamic backend discovery (planned)
- 🛡️ **Rate Limiting** — Custom middleware with full metric export
- 🔧 **Kubernetes Ready** — Includes Helm chart, Dockerfile, Makefile

---

## 🚀 Quick Start

### 🐳 Docker
```bash
docker build -t guardplus .
docker run -p 8080:8080 \
  -v $(pwd)/config.yaml:/app/config.yaml \
  -v $(pwd)/cert.pem:/app/cert.pem \
  -v $(pwd)/key.pem:/app/key.pem \
  guardplus
```

### ⎈ Helm (Kubernetes)
```bash
helm install guardplus ./chart \
  --set image.repository=guardplus --set image.tag=latest
```

---

## ⚙️ Configuration Example (`config.yaml`)

```yaml
http_port: 8080

auth:
  oidc_providers:
    - name: google
      issuer_url: "https://accounts.google.com"
      audience: "your-client-id"

tls:
  cert_path: "./cert.pem"
  key_path: "./key.pem"

consul:
  enabled: true
  url: "http://localhost:8500"

backends:
  - name: http-api
    protocol: http
    address: "http://localhost:9000"
    routes: ["/api/"]
```

---

## 📈 Metrics
Exposed at `/metrics` in Prometheus format.

| Metric                            | Description                           |
|----------------------------------|---------------------------------------|
| `guardplus_backend_requests`     | Count of routed requests              |
| `guardplus_response_latency_ms`  | Histogram of request durations        |
| `guardplus_grpc_requests`        | gRPC service/method counts            |
| `guardplus_tls_cert_expiry_days`| TLS cert expiration timeline          |
| `guardplus_ratelimit_blocked`    | Count of blocked requests             |

---

## 📊 Grafana Dashboard
Use the included JSON dashboard:
📥 `guardplus_grafana_dashboard.json`

---

## 🛡️ Maturity Overview

| Capability                       | Status          |
|----------------------------------|-----------------|
| OIDC/Authn/Authz                 | ✅ Production    |
| HTTP/gRPC/TCP Proxying           | ✅ Production    |
| Metrics + Observability          | ✅ Production    |
| TLS Termination                  | ✅ Production    |
| Rate Limiting                    | ✅ Stable        |
| Consul Discovery                 | 🛠️ Planned       |
| Hot Config Reload                | 🛠️ Planned       |
| UI/Dashboard                     | ❌ Not yet       |
| Canary / A/B Routing             | 🛠️ Next phase    |

---

## 🙋 Contributing
Want to build Rust-powered edge tooling? PRs welcome!

## 📄 License
Apache-2.0
